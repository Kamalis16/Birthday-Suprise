GEETHA'S BIRTHDAY SURPRISE WEBSITE — CHAMPAGNE THEME

HOW TO OPEN IN VS CODE
1. Extract the ZIP file.
2. Open VS Code -> File -> Open Folder -> select this extracted folder.
3. Install the Live Server extension if needed.
4. Right-click index.html -> Open with Live Server.

WEBSITE FLOW
1. First page: click all 5 balloons. After all balloons pop, the surprise button appears.
2. Click the surprise button.
3. Birthday password: 31102006
4. View the five-photo scrapbook, open the letter envelope, and see the final wish.

ADD YOUR PHOTOS (NO CHOOSE FILE BUTTONS ON THE WEBSITE)
Put your own images into the images folder and name them exactly:
- cake.jpg
- bouquet.jpg
- envelope.jpg
- photo1.jpg
- photo2.jpg
- photo3.jpg
- photo4.jpg
- photo5.jpg

The background image is already included as images/birthday-background.png.
Keep the same filenames, or update the corresponding src= value in index.html.

MUSIC
Put the audio file at music/remo-bgm.mp3. Browsers may block autoplay with sound until the visitor interacts with the page.

NOTE
The site is a static HTML/CSS/JavaScript project. You can run it locally with Live Server. For a public website, upload the whole extracted folder to a static website host after adding your images and music.
