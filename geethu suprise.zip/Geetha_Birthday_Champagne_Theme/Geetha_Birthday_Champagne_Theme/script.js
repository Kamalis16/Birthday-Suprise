 
const screens = [
  "giftScreen",
  "welcomeScreen",
  "lockScreen",
  "memoryScreen",
  "letterScreen",
  "finalScreen"
];

const $ = (id) => document.getElementById(id);

function showScreen(id) {
  screens.forEach(screenId => {
    const screen = $(screenId);
    if (screen) {
      screen.classList.toggle("active", screenId === id);
    }
  });

  window.scrollTo({ top: 0, behavior: "smooth" });
}

// FIRST PAGE: OPEN THE GIFT BY TOUCHING THE BOW
$("giftBox").addEventListener("click", () => {
  const gift = $("giftBox");

  if (gift.classList.contains("open")) return;

  gift.classList.add("open");
  $("giftHint").textContent =
    "Your surprise is waiting, Geetha! 💗";

  confetti(25);

  setTimeout(() => {
    showScreen("welcomeScreen");
  }, 1300);
});

// CONFETTI ANIMATION
function confetti(amount = 22) {
  const layer = $("confettiLayer");

  if (!layer) return;

  const pieces = ["♡", "✿", "🎀", "✨", "🌸"];

  for (let i = 0; i < amount; i++) {
    const piece = document.createElement("span");

    piece.className = "confetti";
    piece.textContent =
      pieces[Math.floor(Math.random() * pieces.length)];

    piece.style.left = `${Math.random() * 100}%`;
    piece.style.animationDelay = `${Math.random() * 0.7}s`;
    piece.style.fontSize = `${14 + Math.random() * 14}px`;

    layer.appendChild(piece);

    setTimeout(() => piece.remove(), 3200);
  }
}

// BALLOON POPPING
let popped = 0;

document.querySelectorAll(".balloon").forEach(balloon => {
  balloon.addEventListener("click", () => {
    if (balloon.classList.contains("popped")) return;

    balloon.classList.add("popped");
    popped++;

    confetti(5);

    if (popped === document.querySelectorAll(".balloon").length) {
      $("balloonHint").textContent =
        "Surprise unlocked! Your little world is waiting ♡";

      $("goToLock").hidden = false;

      confetti(28);
    }
  });
});

// NAVIGATION TO PASSWORD PAGE
$("goToLock").addEventListener("click", () => {
  showScreen("lockScreen");
});

// PASSWORD CHECK
$("unlockButton").addEventListener("click", unlock);

$("birthdayPassword").addEventListener("keydown", e => {
  if (e.key === "Enter") unlock();
});

function unlock() {
  const value = $("birthdayPassword").value.trim();

  if (value === "31102006") {
    $("passwordMessage").textContent =
      "Yay! The birthday girl found the magic code! ♡";

    confetti(35);

    setTimeout(() => {
      showScreen("memoryScreen");
    }, 650);
  } else {
    $("passwordMessage").textContent =
      "Not quite, birthday girl! Try your special date again 🎀";

    $("birthdayPassword").focus();
  }
}

// BACK BUTTONS
document.querySelectorAll("[data-back]").forEach(button => {
  button.addEventListener("click", () => {
    showScreen(button.dataset.back);
  });
});

// GO TO LETTER
$("toLetter").addEventListener("click", () => {
  showScreen("letterScreen");
});

// OPEN THE BIRTHDAY LETTER
$("openLetter").addEventListener("click", () => {
  const envelope = $("openLetter");

  if (envelope.classList.contains("open")) return;

  envelope.classList.add("open");

  envelope.querySelector(".tap-label").textContent =
    "opened with love ♡";

  setTimeout(() => {
    $("letterPaper").hidden = false;
    $("toFinal").hidden = false;

    confetti(14);

    $("letterPaper").scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }, 650);
});

// GO TO FINAL BIRTHDAY WISH
$("toFinal").addEventListener("click", () => {
  showScreen("finalScreen");
  confetti(35);
});

// REPLAY: RESET EVERYTHING AND RETURN TO THE GIFT
$("replayButton").addEventListener("click", () => {
  // Reset balloons
  popped = 0;

  document.querySelectorAll(".balloon").forEach(balloon => {
    balloon.classList.remove("popped");
  });

  $("goToLock").hidden = true;

  $("balloonHint").textContent =
    "🎈 Click the balloons to reveal your surprise 🎈";

  // Reset password
  $("birthdayPassword").value = "";
  $("passwordMessage").textContent = "";

  // Reset letter
  $("openLetter").classList.remove("open");

  $("openLetter").querySelector(".tap-label").textContent =
    "tap to open your letter";

  $("letterPaper").hidden = true;
  $("toFinal").hidden = true;

  // Reset gift box and bow
  $("giftBox").classList.remove("open");

  $("giftHint").textContent =
    "🎀 Touch the bow to open your gift 🎀";

  // Return to the first page
  showScreen("giftScreen");
});

// BACKGROUND MUSIC
const bgmAudio = $("bgmAudio");

if (bgmAudio) {
  bgmAudio.volume = 0.55;

  const tryAutoPlay = () => {
    bgmAudio.play().catch(() => {
      // The browser may block autoplay until the visitor interacts.
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      tryAutoPlay,
      { once: true }
    );
  } else {
    tryAutoPlay();
  }

  // Try playing again after the visitor touches the gift
  $("giftBox").addEventListener("click", () => {
    bgmAudio.play().catch(() => {});
  });
}
